#!/bin/bash

# Clear Screen
clear

# Colors
Y='\033[1;33m'
BGX="\033[42m"
CYAN="\033[96m"
RED='\033[0;31m'
NC='\033[0m' # No Color
gray="\e[1;30m"
Blue="\033[0;34m"
orange_bold='\033[1;38;5;214m'
green='\033[0;32m'
grenbo="\e[92;1m"
purple="\033[1;95m"
bold_white="\033[1;97m"

# System Info
ISP=$(cat /etc/xray/isp 2>/dev/null || echo "Unknown")
CITY=$(cat /etc/xray/city 2>/dev/null || echo "Unknown")
IPVPS=$(curl -s ipv4.icanhazip.com)
domain=$(cat /etc/xray/domain 2>/dev/null || echo "Unknown")
RAM=$(free -m | awk 'NR==2 {print $2}')
USAGERAM=$(free -m | awk 'NR==2 {print $3}')
MEMOFREE=$(free -m | awk 'NR==2{printf "%.2f%%", $3*100/$2 }')
LOADCPU=$(top -bn1 | awk '/Cpu/ {printf "%.2f%%", 100 - $8}')
MODEL=$(grep -w PRETTY_NAME /etc/os-release | cut -d'=' -f2 | tr -d '"')
CORE=$(nproc)
DATEVPS=$(date +'%d/%m/%Y')
TIMEZONE=$(date +'%H:%M:%S')
SERONLINE=$(uptime -p | cut -d " " -f 2-)

# User Info
MYIP=$(curl -sS ipv4.icanhazip.com)
today=$(date +"%Y-%m-%d")
exp_date=$(date -d "$valid" +%s 2>/dev/null || echo 0)
today_date=$(date -d "$today" +%s)
certifacate=$(( (exp_date - today_date) / 86400 ))

# Status
if [[ $today < $valid ]]; then
    sts="${green}Active${NC}"
else
    sts="${RED}Expired${NC}"
fi

# Loading
clear
echo -e "\e[32mLoading...\e[0m"

# System Info
uptime="$(uptime -p | cut -d " " -f 2-)"
cpu_usage1="$(ps -eo %cpu | awk 'NR>1 {sum+=$1} END {print sum}')"
cpu_usage="${cpu_usage1%.*}%"

WKT=$(curl -s ipinfo.io/timezone || echo "Unknown")
DAY=$(date +%A)
DATE=$(date +%m/%d/%Y)
DATE2=$(date -R | cut -d " " -f -5)
IPVPS=$(curl -s ipinfo.io/ip || echo "0.0.0.0")

cname=$(awk -F: '/model name/ {print $2; exit}' /proc/cpuinfo)
cores=$(nproc)
freq=$(awk -F: '/cpu MHz/ {print $2; exit}' /proc/cpuinfo)
tram=$(free -m | awk 'NR==2 {print $2}')
uram=$(free -m | awk 'NR==2 {print $3}')
fram=$(free -m | awk 'NR==2 {print $4}')

# Service Status Function
check_service_status() {
  systemctl is-active --quiet "$1" && echo "${green}ON✓${NC}" || echo "${RED}OFF${NC}"
}

# Services
status_ssh=$(check_service_status ssh)
status_dropbear=$(check_service_status dropbear)
status_haproxy=$(check_service_status haproxy)
status_xray=$(check_service_status xray)
status_nginx=$(check_service_status nginx)
status_ws_epro=$(check_service_status ws)

# Account Info
vlx=$(grep -c -E "^#& " "/etc/xray/config.json")
vla=$((vlx / 2))
vmc=$(grep -c -E "^### " "/etc/xray/config.json")
vma=$((vmc / 2))
ssh1=$(awk -F: '$3 >= 1000 && $1 != "nobody"' /etc/passwd | wc -l)
trx=$(grep -c -E "^#! " "/etc/xray/config.json")
trb=$((trx / 2))
ssx=$(grep -c -E "^#ss# " "/etc/xray/config.json")
ssa=$((ssx / 2))

# Define Color Variables
KANAN="\033[1;32m<\033[1;33m<\033[1;31m<\033[1;31m$NC"
KIRI="\033[1;32m>\033[1;33m>\033[1;31m>\033[1;31m$NC"
r="\033[1;31m"  # RED BRIGHT
a="${CYAN}PREMIUM ACCOUNTS"

# Display System Information
clear
echo -e "${z}╭══════════════════════════════════════════════════════════╮${NC}"
echo -e "${z}│$NC$r ⇲ ${y} SYSTEM OS     $Blue=$grenbo $MODEL $NC"
echo -e "${z}│$NC$r ⇲ ${y} SYSTEM CORE   $Blue=$grenbo $CORE $NC"
echo -e "${z}│$NC$r ⇲ ${y} SERVER RAM    $Blue=$grenbo $uram/$RAM MB $NC"
echo -e "${z}│$NC$r ⇲ ${y} SERVER UPTIME $Blue=$grenbo $SERONLINE $NC"
echo -e "${z}│$NC$r ⇲ ${y} DOMAIN        $Blue=$grenbo $domain $NC"
echo -e "${z}│$NC$r ⇲ ${y} IP VPS        $Blue=$grenbo $IPVPS $NC"
echo -e "${z}│$NC$r ⇲ ${y} ISP           $Blue=$grenbo $ISP $NC"
echo -e "${z}│$NC$r ⇲ ${y} CITY          $Blue=$grenbo $CITY $NC"
echo -e "${z}│$NC$r ⇲ ${y} DATE          $Blue=$grenbo $DATEVPS $NC"
echo -e "${z}│$NC$r ⇲ ${y} TIME          $Blue=$grenbo $TIMEZONE $NC"
echo -e "${z}╰══════════════════════════════════════════════════════════╯${NC}"

# Display Account Status
echo -e "               ${KIRI} ${purple}CHECK REGISTERED ACCOUNTS${NC} ${KANAN}"
echo -e "        ${RED}❒════════════════════════════════════════════❒${NC}"
echo -e "        ${CYAN}  SSH/OPENVPN         $y➤$NC $ssh1${NC} $a"
echo -e "        ${CYAN}  VMESS/WS/GRPC       $y➤$NC $vma${NC} $a"
echo -e "        ${CYAN}  VLESS/WS/GRPC       $y➤$NC $vla${NC} $a"
echo -e "        ${CYAN}  TROJAN/WS/GRPC      $y➤$NC $trb${NC} $a"
echo -e "        ${CYAN}  SHADOWSOCKS/WS/GRPC $y➤$NC $ssa${NC} $a"
echo -e "        ${RED}❒════════════════════════════════════════════❒${NC}"

# Display Service Status
echo -e "${z}╭════════════════╮╭══════════════════╮╭════════════════════╮${NC}"
echo -e "${z}│ SSH: $status_ssh │ NGINX: $status_nginx │ XRAY: $status_xray $NC${z}│${NC}"
echo -e "${z}│ WS-ePRO: $status_ws_epro │ DROPBEAR: $status_dropbear │ HAPROXY: $status_haproxy $NC${z}│${NC}"
echo -e "${z}╰════════════════╯╰══════════════════╯╰════════════════════╯${NC}"

# Display Menu
echo -e "${z}╭══════════════════════════════════════════════════════════╮${NC}"
echo -e "${z}│${NC} [${grenbo}01${NC}] SSH MENU      ${z}│${NC} [${grenbo}08${NC}] DELETE ALL EXP ${NC} ${z}│${NC} [${grenbo}15${NC}] BACKUP/RESTORE ${NC}${z}${NC}"
echo -e "${z}│${NC} [${grenbo}02${NC}] VMESS MENU    ${z}│${NC} [${grenbo}09${NC}] AUTO REBOOT    ${NC} ${z}│${NC} [${grenbo}16${NC}] REBOOT         ${NC}${z}${NC}"
echo -e "${z}│${NC} [${grenbo}03${NC}] VLESS MENU    ${z}│${NC} [${grenbo}10${NC}] INFO PORT      ${NC} ${z}│${NC} [${grenbo}17${NC}] RESTART        ${NC}${z}${NC}"
echo -e "${z}│${NC} [${grenbo}04${NC}] TROJAN MENU   ${z}│${NC} [${grenbo}11${NC}] SPEEDTEST      ${NC} ${z}│${NC} [${grenbo}18${NC}] DOMAIN         ${NC}${z}${NC}"
echo -e "${z}│${NC} [${grenbo}05${NC}] SHADOW MENU   ${z}│${NC} [${grenbo}12${NC}] RUNNING        ${NC} ${z}│${NC} [${grenbo}19${NC}] CERT SSL       ${NC}${z}${NC}"
echo -e "${z}│${NC} [${grenbo}06${NC}] LIMIT SPEED   ${z}│${NC} [${grenbo}13${NC}] CLEAR LOG      ${NC} ${z}│${NC} [${grenbo}20${NC}] INSTALL UDP    ${NC}${z}${NC}"
echo -e "${z}│${NC} [${grenbo}07${NC}] VPS INFO      ${z}│${NC} [${grenbo}14${NC}] CHECK BANDWIDTH${NC} ${z}│${NC} [${grenbo}21${NC}] CLEAR CACHE    ${NC}${z}${NC}"
echo -e ""
echo -e "${z}│${NC} [${grenbo}22${NC}] BOT NOTIF     ${z}|${NC} [${grenbo}23${NC}] UPDATE SCRIPT  ${NC} ${z}|${NC}  [${grenbo}24${NC}] BOT PANEL     ${NC}${z}${NC}"
echo -e "${z}│${NC} [${grenbo}25${NC}] CHANGE BANNER ${z}|${NC} [${grenbo}00${NC}] BACK TO EXIT   ${NC} ${z}|${NC}"
echo -e "${z}╰══════════════════════════════════════════════════════════╯${NC}"


# Display Footer Information
echo -e "${z}╭──────────────────────────────────────────────────────────╮${NC}"
echo -e "${z}│$NC$y VERSION$NC    ${Blue}=$NC V3.5.1 $NC"
echo -e "${z}│$NC$y STATUS $NC    ${Blue}=$NC $sts $NC"
echo -e "${z}│$NC$y EXPIRY $NC    ${Blue}=$green $certifacate Days $NC"
echo -e "${z}╰──────────────────────────────────────────────────────────╯${NC}"


  read -rp "Select an option: " opt
  clear

  case $opt in
    1|01) m-sshws;;
    2|02) m-vmess;;
    3|03) m-vless;;
    4|04) m-trojan;;
    5|05) m-ssws;;
    6|06) limitspeed;;
    7|07) gotop; sleep 1;;
    8|08) xp; sleep 1;;
    9|09) autoreboot;;
    10)   prot; read -n 1 -s -r -p "Press any key to return to menu";;
    11)   speedtest; read -n 1 -s -r -p "Press any key to return to menu";;
    12)   run;;
    13)   clearlog;;
    14)   bw;;
    15)   menu-backup;;
    16)   reboot;;
    17)   restart;;
    18)   addhost;;
    19)   fixcert;;
    20)   wget --load-cookies /tmp/cookies.txt ${UDPX} -O install-udp && rm -rf /tmp/cookies.txt && chmod +x install-udp && ./install-udp;;
    21)   clearcache;;
    22)   bot;;
    23)   wget https://raw.githubusercontent.com/SaputraTech/M4k4r0n1/main/update.sh && chmod +x update.sh && ./update.sh;;
    24)   add-bot-panel;;
    25)   nano /etc/kyt.txt;;
    00)   figlet "CHAPEEY TECH" | lolcat --seed 42; exit;;
    xx)   break;;
    *)    echo -e "Invalid option! Please try again.";;
  esac

done